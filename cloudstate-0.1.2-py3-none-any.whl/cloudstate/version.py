"""
Copyright 2020 Lightbend Inc.
Licensed under the Apache License, Version 2.0.
"""

__version__ = "0.1.2"
