"""
Copyright 2020 Lightbend Inc.
Licensed under the Apache License, Version 2.0.
"""

from .version import __version__

__all__ = [
    "__version__",
]
